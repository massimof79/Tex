<?php
require __DIR__ . "/config.php";
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER["REQUEST_METHOD"] !== "POST") { http_response_code(405); echo json_encode(["ok"=>false,"error"=>"Metodo non consentito"]); exit; }

$data = json_decode(file_get_contents("php://input"), true);
if (!is_array($data)) { http_response_code(400); echo json_encode(["ok"=>false,"error"=>"JSON non valido"]); exit; }

function s($x){ $x = trim((string)($x ?? "")); return $x==="" ? null : $x; }

$cognome = s($data["cognome"] ?? null);
$nome = s($data["nome"] ?? null);
$numero_tessera = s($data["numero_tessera"] ?? null);
$data_nascita = s($data["data_nascita"] ?? null);

if (!$cognome || !$nome || !$numero_tessera || !$data_nascita) {
  http_response_code(400);
  echo json_encode(["ok"=>false,"error"=>"Compila cognome, nome, numero_tessera, data_nascita"]);
  exit;
}

$sql = "INSERT INTO clienti (cognome,nome,numero_tessera,data_nascita,email,telefono,codice_fiscale,indirizzo,citta,cap,provincia,note)
        VALUES (:cognome,:nome,:numero_tessera,:data_nascita,:email,:telefono,:codice_fiscale,:indirizzo,:citta,:cap,:provincia,:note)";
try {
  $stmt = $pdo->prepare($sql);
  $stmt->execute([
    ":cognome"=>$cognome,
    ":nome"=>$nome,
    ":numero_tessera"=>$numero_tessera,
    ":data_nascita"=>$data_nascita,
    ":email"=>s($data["email"] ?? null),
    ":telefono"=>s($data["telefono"] ?? null),
    ":codice_fiscale"=>s($data["codice_fiscale"] ?? null),
    ":indirizzo"=>s($data["indirizzo"] ?? null),
    ":citta"=>s($data["citta"] ?? null),
    ":cap"=>s($data["cap"] ?? null),
    ":provincia"=>s($data["provincia"] ?? null),
    ":note"=>s($data["note"] ?? null),
  ]);
  http_response_code(201);
  echo json_encode(["ok"=>true,"id"=>(int)$pdo->lastInsertId()]);
} catch (PDOException $e) {
  if (($e->getCode() ?? "") === "23000") { http_response_code(409); echo json_encode(["ok"=>false,"error"=>"numero_tessera/codice_fiscale già presente"]); exit; }
  http_response_code(500);
  echo json_encode(["ok"=>false,"error"=>"Errore inserimento"]);
}
?>