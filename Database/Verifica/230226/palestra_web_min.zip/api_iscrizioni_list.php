<?php
require __DIR__ . "/config.php";
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER["REQUEST_METHOD"] !== "GET") { http_response_code(405); echo json_encode(["ok"=>false,"error"=>"Metodo non consentito"]); exit; }

$data_da = trim((string)($_GET["data_da"] ?? ""));
$data_a  = trim((string)($_GET["data_a"] ?? ""));

$where = [];
$params = [];

if ($data_da !== "") { $where[] = "i.data_iscrizione >= :da"; $params[":da"] = $data_da; }
if ($data_a  !== "") { $where[] = "i.data_iscrizione <= :a";  $params[":a"]  = $data_a; }

$sql = "SELECT
          i.id AS id_iscrizione,
          i.data_iscrizione,
          i.data_scadenza_iscrizione,
          i.certificato_medico,
          c.cognome, c.nome, c.numero_tessera,
          co.nome AS nome_corso
        FROM iscrizioni i
        JOIN clienti c ON c.id = i.cliente_id
        LEFT JOIN corsi co ON co.id = i.corso_id";

if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY i.data_iscrizione DESC, i.id DESC";

try {
  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  echo json_encode(["ok"=>true,"data"=>$stmt->fetchAll()]);
} catch (Exception $e) {
  http_response_code(500);
  echo json_encode(["ok"=>false,"error"=>"Errore lettura"]);
}
?>