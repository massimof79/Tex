<?php
require __DIR__."/config.php";
header("Content-Type: application/json; charset=utf-8");

if($_SERVER["REQUEST_METHOD"]!=="GET"){ http_response_code(405); echo json_encode(["ok"=>false,"error"=>"Metodo non consentito"]); exit; }

$data_da=trim((string)($_GET["data_da"]??""));
$data_a =trim((string)($_GET["data_a"]??""));

$where=[]; $params=[];
if($data_da!==""){ $where[]="p.data_prestito >= :da"; $params[":da"]=$data_da; }
if($data_a!==""){  $where[]="p.data_prestito <= :a";  $params[":a"] =$data_a; }

$sql="SELECT
        p.id AS id_prestito,
        p.data_prestito,
        p.data_scadenza,
        p.data_restituzione,
        u.cognome, u.nome, u.tessera,
        l.titolo, l.autore, l.isbn,
        b.nome AS biblioteca, b.citta
      FROM prestiti p
      JOIN utenti u ON u.id = p.utente_id
      JOIN libri l ON l.id = p.libro_id
      JOIN biblioteche b ON b.id = l.biblioteca_id";

if($where) $sql.=" WHERE ".implode(" AND ",$where);
$sql.=" ORDER BY p.data_prestito DESC, p.id DESC";

try{
  $stmt=$pdo->prepare($sql);
  $stmt->execute($params);
  echo json_encode(["ok"=>true,"data"=>$stmt->fetchAll()]);
}catch(Exception $e){
  http_response_code(500);
  echo json_encode(["ok"=>false,"error"=>"Errore lettura"]);
}
?>