<?php
require __DIR__."/config.php";
header("Content-Type: application/json; charset=utf-8");

if($_SERVER["REQUEST_METHOD"]!=="POST"){ http_response_code(405); echo json_encode(["ok"=>false,"error"=>"Metodo non consentito"]); exit; }

$data=json_decode(file_get_contents("php://input"),true);
if(!is_array($data)){ http_response_code(400); echo json_encode(["ok"=>false,"error"=>"JSON non valido"]); exit; }

function s($x){ $x=trim((string)($x??"")); return $x===""?null:$x; }

$cognome=s($data["cognome"]??null);
$nome=s($data["nome"]??null);
$tessera=s($data["tessera"]??null);
$data_iscrizione=s($data["data_iscrizione"]??null); // YYYY-MM-DD

if(!$cognome||!$nome||!$tessera||!$data_iscrizione){
  http_response_code(400);
  echo json_encode(["ok"=>false,"error"=>"Compila cognome, nome, tessera, data_iscrizione"]);
  exit;
}

$sql="INSERT INTO utenti (cognome,nome,email,tessera,data_iscrizione)
      VALUES (:cognome,:nome,:email,:tessera,:data_iscrizione)";
try{
  $stmt=$pdo->prepare($sql);
  $stmt->execute([
    ":cognome"=>$cognome,
    ":nome"=>$nome,
    ":email"=>s($data["email"]??null),
    ":tessera"=>$tessera,
    ":data_iscrizione"=>$data_iscrizione
  ]);
  http_response_code(201);
  echo json_encode(["ok"=>true,"id"=>(int)$pdo->lastInsertId()]);
}catch(PDOException $e){
  if(($e->getCode()??"")==="23000"){ http_response_code(409); echo json_encode(["ok"=>false,"error"=>"tessera/email già presente (vincolo UNIQUE)"]); exit; }
  http_response_code(500);
  echo json_encode(["ok"=>false,"error"=>"Errore inserimento"]);
}
?>